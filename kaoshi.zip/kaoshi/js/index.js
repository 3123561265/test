var week = document.querySelector('.week')
var hour = document.querySelector('.hour');
var minute = document.querySelector('.minute');
var second = document.querySelector('.second');
countDown();
setInterval(countDown, 1000);
function countDown() {
    var dt=new Date();
    var weekDay = ["星期天", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
    var w = weekDay[dt.getDay()]; 
    week.innerHTML = w;
    var h=dt.getHours();
    h = h < 10 ? '0' + h : h;
    hour.innerHTML = h+":";
    var m=dt.getMinutes();
    m = m < 10 ? '0' + m : m;
    minute.innerHTML = m+":";
    var s = dt.getSeconds();
    s = s < 10 ? '0' + s : s;
    second.innerHTML = s;
}
var tubiao = document.querySelector('.rtop_tubiao');
var inputTime = +new Date('2050-5-1 18:00:00');
setInterval(jiahaoDown, 1000);
function jiahaoDown(){
    var nowTime = +new Date();
    var times = (inputTime - nowTime)/1000; 
    var s = parseInt(times % 60);
    if(s%2==0){
        tubiao
    }
}

function random(num) {
    return Math.floor(Math.random()*num)
  }

  function getRandomStyles() {
    var r = random(255);
    var g = random(255);
    var b = random(255);
    var mt = random(200);
    var ml = random(50);
    var dur = random(5)+5;
    return `
    background-color: rgba(${r},${g},${b},0.7);
    color: rgba(${r},${g},${b},0.7); 
    box-shadow: inset -7px -3px 10px rgba(${r-10},${g-10},${b-10},0.7);
    margin: ${mt}px 0 0 ${ml}px;
    animation: float ${dur}s ease-in infinite
    `
  }
  function createBalloons(num) {
    var balloonContainer = document.getElementById("balloon-container")
    for (var i = num; i > 0; i--) {
    var balloon = document.createElement("div");
    balloon.className = "balloon";
    balloon.style.cssText = getRandomStyles();
     balloonContainer.append(balloon);
    }
  }
  window.onload = function() {
    createBalloons(100);
  }


 var sliderbar = document.querySelector('.slider-bar');
 var w = document.querySelector('.w');
 var wTop = w.offsetTop;
 var sliderbarTop = sliderbar.offsetTop-wTop;
 var wheels=document.querySelector('.wheels');
 document.addEventListener('scroll',function(){
   var juli=window.pageYOffset/screen.availHeight*screen.availHeight+40;
   wheels.style.left=juli+'px';
    if(window.pageYOffset>=wTop){
      sliderbar.style.display = 'block';
      sliderbar.style.position = 'fixed';
      sliderbar.style.top = sliderbarTop+'px';
    }
    else {
      sliderbar.style.display = 'none';
      sliderbar.style.position = 'absolute';
      sliderbar.style.top = '600px';
    }
 })

